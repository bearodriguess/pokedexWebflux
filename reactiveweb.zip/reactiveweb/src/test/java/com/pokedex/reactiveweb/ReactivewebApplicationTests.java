package com.pokedex.reactiveweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactivewebApplicationTests {

	@Test
	void contextLoads() {
	}

}
